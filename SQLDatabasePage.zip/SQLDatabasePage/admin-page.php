<?php include("header.php");
  session_start();
  $user = ($_SESSION['sess_user']);
  if(!isset($_SESSION['sess_user'])){
    header("Location: login-form.php");
    exit();
  }
  // echo $user;
?>
  <nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand">Welcome, <?php echo $user ?></a>
      </div>
      <ul class="nav navbar-nav navbar-right">
        <li><a class="navbar-brand" href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
      </ul>
    </div>
  </nav>
  <h3 style="font-size:28px; font-weight:bold;">List of User table from Northwind</h3>

  <?php
      $con = mysql_connect('localhost','root','') or die(mysql_error());
      mysql_select_db('Northwind') or die("cannot select DB");

      $result = mysql_query("show tables"); // run the query and assign the result to $result
      while($table = mysql_fetch_array($result))
      {
        // go through each row that was returned in $result
        echo "<a class='button' style='font-size:18px; font-weight:bold' onclick=\"location.href='sqlQuery.php?data=$table[0]'\">".$table[0]."</a>" ."<br>";
      }

  ?>
<?php include("footer.php"); ?>
