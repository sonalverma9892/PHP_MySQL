<?php include("header.php"); ?>

        <div class="container">
          <div class="row">
            <div class="col-md-offset-5 col-md-3">
              <form  class"form-group" action="login-form.php" method="post">
                  <h2 style="font-weight:bold; text-align:center">Login</h2><br><br>

                  <label style="font-size:18px;font-weight:bold">Username:</label><br>
                  <div class="input-group">
                    <span class="input-group-addon">
                      <i class="glyphicon glyphicon-user" style="width: auto"></i>
                    </span>
                    <input class="form-control input-sm chat-input" type="text" name="username"class="form-control" style="width: 100%" placeholder="Enter Email">
                  </div><br>

                  <label style="font-size:18px;font-weight:bold">Password:</label><br>
                  <div class="input-group">
                    <span class="input-group-addon">
                      <i class="glyphicon glyphicon-lock" style="width: auto"></i>
                    </span>
                    <input type="password" name="password" class="form-control input-sm chat-input" style="width: 100%" placeholder="Enter password">
                  </div><br>

                  <button type="submit" class="btn btn-primary" name="submit" style="width: 100%">Login<i class="glyphicon glyphicon-log-in"></i></button>
              </form>
            </div>
          </div>
        </div>

        <?php
        if(isset($_POST["submit"])){

        if(!empty($_POST['username']) && !empty($_POST['password'])) {
            $user = $_POST['username'];
            $pass = $_POST['password'];

            $con = mysql_connect('localhost','root','') or die(mysql_error());
            mysql_select_db('Northwind') or die("cannot select DB");

            $query = mysql_query("SELECT * FROM DBUSERS WHERE USERNAME='".$user."' AND PASSWORD='".$pass."'");
            $numrows = mysql_num_rows($query);
            if($numrows != 0)
            {
                while($row = mysql_fetch_assoc($query))
                {
                  $dbusername = $row['USERNAME'];
                  $dbpassword = $row['PASSWORD'];
                  $dbtype = $row['TYPE'];
                  // echo $dbtype;
                }

              if(($user == $dbusername && $pass == $dbpassword) && ($dbtype == 'A'))
              {
                session_start();
                $_SESSION['sess_user'] = $user;
                /* Redirect browser */
                header("Location: admin-page.php");
              }else{
                $message = '<span style = "color:red; margin-left:45%; font-weight:bold">You do not have access to this area!</span>';
                echo $message;
                // echo "<script type='text/javascript'>alert('$message');</script>";
                return false;
                // header("Location: login-form.php");
              }

            } else {
              $message = '<span style ="color:red; margin-left:47%; font-weight:bold">Sorry, Not a registered User!</span>';
              echo $message;
              // echo "<script type='text/javascript'>alert('$message');</script>";
              return false;
              // header("Location: login-form.php");
            }

        } else {
          $message = '<span style = "color:red; margin-left:50%; font-weight:bold">All fields are required!</span>';
          echo $message;
          // echo "<script type='text/javascript'>alert('$message');</script>";
          return false;
        }
        }
        ?>


<?php include("footer.php"); ?>
