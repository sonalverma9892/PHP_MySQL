<?php include("header.php");
  session_start();
  $user = ($_SESSION['sess_user']);
  if(!isset($_SESSION['sess_user'])){
    header("Location: login-form.php");
    exit();
  }
  $con = mysql_connect('localhost','root','') or die(mysql_error());
  mysql_select_db('Northwind') or die("cannot select DB");
?>

    <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand">Welcome to SQL!</a>
        </div>
        <ul class="nav navbar-nav navbar-right">
          <li><a class="navbar-brand" href="admin-page.php">Back</a></li>
        </ul>
      </div>
    </nav>

    <?php
      if(isset($_GET["data"])){
        $tablename = $_GET["data"];
        echo "<p style='font-size:24px; font-weight:bold;'>Table: ".$tablename."</p> <br>";
      }

      $tableheader = false;
      $result = mysql_query("SHOW COLUMNS FROM  .$tablename");
      $fields = array();
      $keys = array();
      while ($fieldinfo = mysql_fetch_assoc($result)){
        $fields[] = $fieldinfo['Field'];
      }
      $comma_separated = implode("`, `", $fields);
      // echo $comma_separated;
      foreach ($fields as $index => $val) {
        $keys[] = '[value-' .$index .']';
      }
      // join array with a comma
      $attusers = implode(', ', $keys);
      // print($attusers);
      $implodeColumn = implode("`=[value], `", $fields);
      // echo $implodeColumn;

      error_reporting(E_ALL ^ E_WARNING);

      $messageSelectall = "SELECT * FROM `".$tablename. "`";
      $messageSelect = "SELECT `" .$comma_separated. "` FROM `" .$tablename. "` WHERE 1";
      $messageInsert = "INSERT INTO `" .$tablename. "` ( `" .$comma_separated. "` ) VALUES (" .$attusers. ")";
      $messageUpdate = "UPDATE `" .$tablename. "` SET `" .$implodeColumn. "` =[value] WHERE 1";
      $messageDelete = "DELETE FROM `" .$tablename. "` WHERE 0";
      $messageClear = '';
    ?>

    <form name="sqlQuery" class="form-group" method="post">
      <textarea class="form-control" rows="5" name="sqlQueryField" ></textarea><br>
      <button style="margin-right:2%" type="button" name="Selectall" class="btn btn-primary" onclick="sqlQuery.sqlQueryField.value = '<?php echo $messageSelectall; ?>'">SELECT*</button>
      <button style="margin-right:2%" type="button" name="Select" class="btn btn-primary" onclick="sqlQuery.sqlQueryField.value = '<?php echo $messageSelect; ?>'">SELECT</button>
      <button style="margin-right:2%" type="button" name="Insert" class="btn btn-primary" onclick="sqlQuery.sqlQueryField.value = '<?php echo $messageInsert; ?>'">INSERT</button>
      <button style="margin-right:2%" type="button" name="Update" class="btn btn-primary" onclick="sqlQuery.sqlQueryField.value = '<?php echo $messageUpdate; ?>'">UPDATE</button>
      <button style="margin-right:2%" type="button" name="Delete" class="btn btn-primary" onclick="sqlQuery.sqlQueryField.value = '<?php echo $messageDelete; ?>'">DELETE</button>
      <button style="margin-right:43%" type="button" name="clear" class="btn btn-primary" onclick="sqlQuery.sqlQueryField.value = '<?php echo $messageClear; ?>'">CLEAR</button>
      <button type="submit" name="go" class="btn btn-primary">GO</button>
    </form>

    <?php

      if(isset($_POST['go'])){
        if (isset($_POST['sqlQueryField'])){
          $query = ($_POST['sqlQueryField']);
          if($res = mysql_query($query) or die(mysql_error())){
            $successMsg = '<span style = "color:green;">Query Successfull!</span>';
            echo $successMsg;

            if(mysql_affected_rows($con) > 0){
              echo "<table class='table table-striped'>";
              while($row = mysql_fetch_assoc($res)){
                if($tableheader == false){
                  echo "<tr>";
                  foreach($row as $key=>$value){
                    echo "<th>{$key}</th>";
                  }
                  echo "</tr>";
                  $tableheader = true;
                }
                echo "<tr>";
               	foreach($row as $value){
               	  echo "<td>{$value}</td>";
               	}
               	echo "</tr>";
              }
              echo "</table>";
              //Close result set
              mysql_free_result($res);
            }
            else{
               echo "No records matching your query were found.";
            }
          }else{
            echo "ERROR: Could not able to execute $query. " . mysql_error($con);
          }
        }
      }
    ?>


<?php include("footer.php"); ?>
