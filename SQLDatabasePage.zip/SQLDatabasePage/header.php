<html>
<head>
    <title>Test 1</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/store.css" rel="stylesheet" />
</head>
<body>
    <div class="container">
